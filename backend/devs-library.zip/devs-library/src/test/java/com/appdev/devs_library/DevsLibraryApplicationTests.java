package com.appdev.devs_library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevsLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
