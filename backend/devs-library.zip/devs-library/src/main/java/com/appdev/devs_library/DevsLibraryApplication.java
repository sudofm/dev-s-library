package com.appdev.devs_library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevsLibraryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevsLibraryApplication.class, args);
	}

}
